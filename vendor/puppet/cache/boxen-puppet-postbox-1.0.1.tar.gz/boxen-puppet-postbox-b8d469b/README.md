# Postbox Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-postbox.png)](https://travis-ci.org/boxen/puppet-postbox)

## Usage

```puppet
include postbox
```

## Required Puppet Modules

* boxen

